import React from 'react';
import Layout from './Component/Layout';
import Carousel from './Carousel/Carousel'; 
function Scheduling() {
  return (
    <Layout>
      <div>
        <Carousel />
      </div>
    </Layout>
    
  );
}
export default Scheduling; 