import Layout from "../Component/Layout"


function Home() {
  return (
    <Layout>
        <div>
            Herosection
        </div>
    </Layout>
  )
}

export default Home